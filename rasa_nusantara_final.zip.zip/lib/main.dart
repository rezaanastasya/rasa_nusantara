import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const RasaNusantaraApp());
}

class RasaNusantaraApp extends StatelessWidget {
  const RasaNusantaraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Rasa Nusantara',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.amber),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}