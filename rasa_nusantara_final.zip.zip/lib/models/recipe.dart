class Recipe {
  final String name;
  final String origin;
  final String description;
  final String category;
  final double rating;
  final List<String> ingredients;
  final List<String> steps;

  Recipe({
    required this.name,
    required this.origin,
    required this.description,
    required this.category,
    required this.rating,
    required this.ingredients,
    required this.steps,
  });
}

final List<Recipe> dummyRecipes = [
  Recipe(
    name: 'Rendang Daging',
    origin: 'Minangkabau, Sumbar',
    description: 'Masakan daging sapi bercita rasa pedas kaya rempah yang dimasak perlahan menggunakan santan kelapa asli hingga kering.',
    category: 'Populer',
    rating: 4.9,
    ingredients: [
      '1 kg Daging Sapi (potong sesuai selera)',
      '1000 ml Santan Kental dari 2 butir kelapa',
      '2 lembar Daun Kunyit, 4 lembar Daun Jeruk',
      '2 batang Serai (memarkan)',
      'Bumbu halus: Bawang merah, bawang putih, cabai merah, jahe, lengkuas.'
    ],
    steps: [
      'Tumis bumbu halus bersama daun kunyit, daun jeruk, dan serai hingga harum.',
      'Masukkan daging sapi, aduk rata hingga daging berubah warna.',
      'Tuangkan santan kental secara perlahan sambil terus diaduk.',
      'Masak dengan api kecil selama beberapa jam hingga santan mengering dan hitam pekat.'
    ],
  ),
  Recipe(
    name: 'Sate Ayam Madura',
    origin: 'Madura, Jawa Timur',
    description: 'Potongan daging ayam pilihan yang dibakar empuk, disajikan dengan siraman bumbu kacang kental dan irisan bawang merah.',
    category: 'Lokal',
    rating: 4.8,
    ingredients: [
      '500 gr Daging Ayam Fillet (potong dadu)',
      '200 gr Kacang Tanah (goreng dan haluskan)',
      'Kecap manis secukupnya',
      'Tusuk sate secukupnya'
    ],
    steps: [
      'Tusuk potongan daging ayam ke tusuk sate.',
      'Haluskan bumbu kacang campur dengan kecap manis dan air hangat.',
      'Olesi sate dengan bumbu kacang lalu bakar hingga matang kecokelatan.',
      'Sajikan dengan siraman bumbu kacang sisa dan bawang goreng.'
    ],
  ),
];