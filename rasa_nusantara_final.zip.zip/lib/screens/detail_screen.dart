import 'package:flutter/material.dart';
import '../models/recipe.dart';

class DetailScreen extends StatelessWidget {
  final Recipe recipe;
  const DetailScreen({super.key, required this.recipe});

  @override
  Widget build(BuildContext context) {
    IconData recipeIcon = Icons.restaurant;
    if (recipe.name.contains('Rendang')) recipeIcon = Icons.dinner_dining;
    if (recipe.name.contains('Sate')) recipeIcon = Icons.kebab_dining;

    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFB),
      appBar: AppBar(
        title: Text(recipe.name),
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: ListView(
        children: [
          Container(
            height: 180,
            width: double.infinity,
            alignment: Alignment.center,
            decoration: const BoxDecoration(color: Color(0xFFFFFBEB)),
            child: Icon(recipeIcon, size: 80, color: Colors.amber[600]),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(recipe.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                Text(recipe.origin, style: const TextStyle(color: Colors.amber, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),
                Text(recipe.description, style: TextStyle(color: Colors.grey[600], height: 1.5)),
                const SizedBox(height: 24),
                const Text('Bahan-Bahan:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                ...recipe.ingredients.map((ing) => Text('• $ing', style: const TextStyle(height: 1.4))),
                const SizedBox(height: 24),
                const Text('Langkah Memasak:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                ...recipe.steps.map((step) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(step, style: const TextStyle(height: 1.4)),
                )),
              ],
            ),
          )
        ],
      ),
    );
  }
}