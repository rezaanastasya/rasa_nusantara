import 'package:flutter/material.dart';
import '../models/recipe.dart';
import 'detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int currentBottomIndex = 0;
  String selectedCategory = 'Semua';
  final List<String> categories = ['Semua', 'Populer', 'Lokal', 'Dessert'];
  final List<Recipe> savedRecipes = [];

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      _buildHomeTab(),
      _buildSavedTab(),
      _buildProfileTab(),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFB),
      body: SafeArea(child: pages[currentBottomIndex]),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentBottomIndex,
        onTap: (index) {
          setState(() {
            currentBottomIndex = index;
          });
        },
        selectedItemColor: Colors.amber,
        unselectedItemColor: Colors.grey[400],
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.white,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            activeIcon: Icon(Icons.home),
            label: 'Beranda',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bookmark_border),
            activeIcon: Icon(Icons.bookmark),
            label: 'Simpanan',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            activeIcon: Icon(Icons.person),
            label: 'Profil',
          ),
        ],
      ),
    );
  }

  Widget _buildHomeTab() {
    final String currentCategory = selectedCategory;
    final filteredRecipes = currentCategory == 'Semua'
        ? dummyRecipes
        : dummyRecipes.where((r) => r.category == currentCategory).toList();

    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Halo, Selamat Datang! 👋', style: TextStyle(color: Colors.grey[600], fontSize: 14)),
                const SizedBox(height: 4),
                const Text('Mau Masak Apa Hari Ini?', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              ],
            ),
            GestureDetector(
              onTap: () => setState(() => currentBottomIndex = 2),
              child: const CircleAvatar(
                radius: 22,
                backgroundColor: Color(0xFFFEF3C7),
                child: Icon(Icons.person, color: Colors.amber),
              ),
            )
          ],
        ),
        const SizedBox(height: 24),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
          ),
          child: const TextField(
            decoration: InputDecoration(
              hintText: 'Cari resep makanan nusantara...',
              prefixIcon: Icon(Icons.search, color: Colors.amber),
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(vertical: 14),
            ),
          ),
        ),
        const SizedBox(height: 24),
        SizedBox(
          height: 38,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: categories.length,
            itemBuilder: (context, index) {
              final cat = categories[index];
              final isSelected = selectedCategory == cat;
              return GestureDetector(
                onTap: () => setState(() => selectedCategory = cat),
                child: Container(
                  margin: const EdgeInsets.only(right: 10),
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  decoration: BoxDecoration(
                    color: isSelected ? Colors.amber : Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Center(
                    child: Text(
                      cat,
                      style: TextStyle(fontWeight: FontWeight.bold, color: isSelected ? Colors.white : Colors.black54),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 24),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: filteredRecipes.length,
          itemBuilder: (context, index) {
            final recipe = filteredRecipes[index];
            final isSaved = savedRecipes.contains(recipe);
            return _buildRecipeCard(recipe, isSaved);
          },
        ),
      ],
    );
  }

  Widget _buildSavedTab() {
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFB),
      appBar: AppBar(title: const Text('Resep Tersimpan', style: TextStyle(color: Colors.black)), backgroundColor: Colors.white, elevation: 0, iconTheme: const IconThemeData(color: Colors.black)),
      body: savedRecipes.isEmpty
          ? const Center(child: Text('Belum ada resep yang disimpan'))
          : ListView.builder(
              padding: const EdgeInsets.all(20),
              itemCount: savedRecipes.length,
              itemBuilder: (context, index) {
                return _buildRecipeCard(savedRecipes[index], true);
              },
            ),
    );
  }

  Widget _buildProfileTab() {
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Center(
          child: Column(
            children: [
              CircleAvatar(radius: 50, backgroundColor: Colors.amber[50], child: const Icon(Icons.person, size: 55, color: Colors.amber)),
              const SizedBox(height: 16),
              const Text('Chef Rasa Nusantara', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
        const SizedBox(height: 32),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Column(children: [Text('${dummyRecipes.length}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), const Text('Total Resep')]),
            Column(children: [Text('${savedRecipes.length}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), const Text('Disimpan')]),
          ],
        )
      ],
    );
  }

  Widget _buildRecipeCard(Recipe recipe, bool isSaved) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => DetailScreen(recipe: recipe)),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 150,
              width: double.infinity,
              alignment: Alignment.center,
              decoration: const BoxDecoration(color: Color(0xFFFFFBEB), borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
              child: Icon(Icons.restaurant_menu, size: 60, color: Colors.amber[600]),
            ),
            Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(recipe.origin, style: const TextStyle(color: Colors.amber, fontWeight: FontWeight.bold, fontSize: 12)),
                  const SizedBox(height: 6),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(recipe.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            if (isSaved) {
                              savedRecipes.remove(recipe);
                            } else {
                              savedRecipes.add(recipe);
                            }
                          });
                        },
                        child: Icon(isSaved ? Icons.favorite : Icons.favorite_border, color: isSaved ? Colors.red : Colors.grey),
                      )
                    ],
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      const Icon(Icons.star, color: Colors.orangeAccent, size: 16),
                      const SizedBox(width: 4),
                      Text(recipe.rating.toString(), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(recipe.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.grey, fontSize: 13)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}