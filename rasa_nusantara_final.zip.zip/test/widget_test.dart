import 'package:flutter_test/flutter_test.dart';
import 'package:rasa_nusantara/main.dart';

void main() {
  testWidgets('Counter value test placeholder', (WidgetTester tester) async {
    await tester.pumpWidget(const RasaNusantaraApp());
  });
}